import React from "react";
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";

export const C = {
  p: "#4F5B93", pl: "#777BB4", px: "#E9EAF6", o: "#E8912D", ox: "#FDF1E2",
  g: "#2A9D8F", gx: "#E3F4F1", r: "#D6453D", rx: "#FBE7E5", ink: "#2B2D42", mut: "#6B6F86", line: "#E3E5EF",
};
const FONT = "'Plus Jakarta Sans', system-ui, sans-serif";
const MONO = "'JetBrains Mono', ui-monospace, monospace";
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const ease = Easing.bezier(0.16, 1, 0.3, 1);

const fade = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], {...clamp, easing: ease});
const type = (text: string, f: number, start: number, cps = 1.2) => text.slice(0, Math.max(0, Math.floor((f - start) * cps)));

const Stage: React.FC<{children: React.ReactNode; title: string; step?: string}> = ({children, title, step}) => (
  <AbsoluteFill style={{background: "linear-gradient(135deg,#FBFBFE 0%,#F1F2FA 100%)", fontFamily: FONT, color: C.ink}}>
    <div style={{position: "absolute", left: 48, top: 34, fontSize: 18, fontWeight: 800, letterSpacing: 3, color: C.o}}>PERTEMUAN 11 · PHP DATABASE CRUD</div>
    <div style={{position: "absolute", left: 48, top: 60, fontSize: 38, fontWeight: 800, letterSpacing: -1}}>{title}</div>
    {children}
    {step ? (
      <div style={{position: "absolute", left: 48, right: 48, bottom: 34, background: "#fff", border: `2px solid ${C.line}`, borderRadius: 18, padding: "16px 24px", fontSize: 24, fontWeight: 600}}>{step}</div>
    ) : null}
  </AbsoluteFill>
);

const Card: React.FC<{x: number; y: number; w: number; h: number; color: string; children?: React.ReactNode; glow?: number; bg?: string}> = ({x, y, w, h, color, children, glow = 0, bg = "#fff"}) => (
  <div style={{position: "absolute", left: x, top: y, width: w, height: h, background: bg, border: `3px solid ${color}`, borderRadius: 22,
    boxShadow: `0 10px 30px rgba(79,91,147,.12), 0 0 0 ${glow * 10}px ${color}33`}}>{children}</div>
);

const Packet: React.FC<{f: number; a: number; b: number; from: [number, number]; to: [number, number]; color: string; label: string}> = ({f, a, b, from, to, color, label}) => {
  const t = interpolate(f, [a, b], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const vis = f >= a && f <= b + 6 ? 1 : 0;
  const x = from[0] + (to[0] - from[0]) * t;
  const y = from[1] + (to[1] - from[1]) * t;
  return (
    <div style={{position: "absolute", left: x, top: y, translate: "-50% -50%", opacity: vis, display: "flex", alignItems: "center", gap: 10}}>
      <div style={{width: 22, height: 22, borderRadius: 11, background: color, boxShadow: `0 0 0 8px ${color}33`}} />
      <div style={{background: color, color: "#fff", fontFamily: MONO, fontSize: 17, fontWeight: 700, padding: "6px 12px", borderRadius: 10, whiteSpace: "nowrap"}}>{label}</div>
    </div>
  );
};

// ------------------------------------------------------------- 1. Request flow
export const RequestFlow: React.FC = () => {
  const f = useCurrentFrame();
  const steps = [
    [0, "1 · Browser mengirim HTTP request ke server"],
    [70, "2 · Apache menyerahkan index.php ke mesin PHP"],
    [110, "3 · PHP mengirim query SQL ke MySQL/MariaDB"],
    [165, "4 · Database mengembalikan result set"],
    [210, "5 · PHP menyusun HTML lalu mengirim response"],
    [255, "6 · Browser menampilkan tabel data mahasiswa"],
  ] as const;
  const cur = [...steps].reverse().find((s) => f >= s[0])!;
  const rows = ["2208160001  Ahmad Fauzi", "2208160014  Siti Rahmadani", "2308160027  Bima Prasetyo"];
  return (
    <Stage title="Perjalanan sebuah request" step={cur[1]}>
      {/* browser */}
      <Card x={60} y={170} w={330} h={300} color={C.pl} glow={f > 255 ? 1 : 0}>
        <div style={{height: 44, background: C.px, borderRadius: "18px 18px 0 0", display: "flex", alignItems: "center", gap: 8, padding: "0 16px"}}>
          {[C.r, C.o, C.g].map((c) => <div key={c} style={{width: 12, height: 12, borderRadius: 6, background: c}} />)}
          <div style={{marginLeft: 10, background: "#fff", borderRadius: 14, padding: "3px 12px", fontFamily: MONO, fontSize: 14, color: C.mut}}>localhost/simak/index.php</div>
        </div>
        <div style={{padding: 18}}>
          <div style={{fontWeight: 800, fontSize: 20, marginBottom: 10}}>Data Mahasiswa</div>
          {rows.map((r, i) => (
            <div key={r} style={{opacity: fade(f, 255 + i * 8, 270 + i * 8), translate: `0px ${interpolate(f, [255 + i * 8, 270 + i * 8], [14, 0], clamp)}px`,
              fontFamily: MONO, fontSize: 15, padding: "8px 10px", background: i % 2 ? "#fff" : "#F4F5FB", borderRadius: 8, marginBottom: 6}}>{r}</div>
          ))}
          {f < 255 ? <div style={{fontSize: 16, color: C.mut, marginTop: 30, textAlign: "center"}}>menunggu response...</div> : null}
        </div>
      </Card>
      {/* server */}
      <Card x={470} y={150} w={340} h={340} color={C.p} bg="#F7F8FD">
        <div style={{textAlign: "center", fontWeight: 800, fontSize: 22, color: C.p, marginTop: 16}}>Web Server (XAMPP)</div>
        <div style={{display: "flex", gap: 16, justifyContent: "center", marginTop: 20}}>
          <div style={{width: 130, height: 110, borderRadius: 18, border: `3px solid ${C.pl}`, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 22, color: C.pl,
            boxShadow: f > 40 && f < 90 ? `0 0 0 10px ${C.pl}33` : "none"}}>Apache</div>
          <div style={{width: 130, height: 110, borderRadius: 18, border: `3px solid ${C.p}`, background: C.px, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 30, color: C.p, fontStyle: "italic",
            boxShadow: (f > 80 && f < 120) || (f > 190 && f < 220) ? `0 0 0 10px ${C.p}33` : "none"}}>php</div>
        </div>
        <div style={{margin: "22px 24px 0", background: "#272822", borderRadius: 12, padding: "12px 14px", fontFamily: MONO, fontSize: 14, color: "#f8f8f2", minHeight: 96}}>
          <div style={{color: "#75715e"}}>// index.php</div>
          <div>{type("$hasil = mysqli_query(...);", f, 85, 1.4)}</div>
          <div>{type("while ($row = fetch_assoc())", f, 190, 1.6)}</div>
        </div>
      </Card>
      {/* database */}
      <div style={{position: "absolute", left: 900, top: 190, width: 300, height: 260}}>
        <svg width="300" height="260" viewBox="0 0 300 260">
          <path d="M20 50 v160 a130 34 0 0 0 260 0 v-160" fill={C.gx} stroke={C.g} strokeWidth="4" />
          <ellipse cx="150" cy="50" rx="130" ry="34" fill="#fff" stroke={C.g} strokeWidth="4" />
          <path d="M20 120 a130 34 0 0 0 260 0" fill="none" stroke={C.g} strokeWidth="3" opacity=".5" />
        </svg>
        <div style={{position: "absolute", top: 150, width: "100%", textAlign: "center", fontWeight: 800, fontSize: 22, color: C.g}}>MySQL / MariaDB</div>
        <div style={{position: "absolute", top: 180, width: "100%", textAlign: "center", fontFamily: MONO, fontSize: 16, color: C.mut}}>db_kampus.mahasiswa</div>
        <div style={{position: "absolute", top: 76, left: 70, right: 70, opacity: fade(f, 150, 165)}}>
          {[0, 1, 2].map((i) => <div key={i} style={{height: 10, borderRadius: 5, background: C.g, opacity: 0.5 + i * 0.15, marginBottom: 6}} />)}
        </div>
      </div>
      <Packet f={f} a={15} b={60} from={[390, 250]} to={[520, 250]} color={C.pl} label="GET /index.php" />
      <Packet f={f} a={110} b={150} from={[810, 260]} to={[920, 260]} color={C.g} label="SELECT * FROM mahasiswa" />
      <Packet f={f} a={165} b={200} from={[920, 380]} to={[810, 380]} color={C.o} label="result set (6 baris)" />
      <Packet f={f} a={215} b={252} from={[520, 400]} to={[390, 400]} color={C.o} label="HTML response" />
    </Stage>
  );
};

// ------------------------------------------------------------- 2. CRUD
type Row = {nim: string; nama: string; email: string};
export const CrudOps: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const ph = f < 90 ? 0 : f < 180 ? 1 : f < 270 ? 2 : 3;
  const P = [
    {k: "C", n: "CREATE", c: C.g, sql: "INSERT INTO mahasiswa (nim, nama, email)\nVALUES (?, ?, ?)", fn: "mysqli_stmt_execute($stmt);"},
    {k: "R", n: "READ", c: C.pl, sql: "SELECT nim, nama, email\nFROM mahasiswa WHERE nama LIKE ?", fn: "mysqli_fetch_assoc($hasil);"},
    {k: "U", n: "UPDATE", c: C.o, sql: "UPDATE mahasiswa SET email = ?\nWHERE id = ?", fn: "mysqli_stmt_affected_rows($stmt);"},
    {k: "D", n: "DELETE", c: C.r, sql: "DELETE FROM mahasiswa\nWHERE id = ?", fn: "mysqli_stmt_affected_rows($stmt);"},
  ][ph];
  const local = f - ph * 90;
  const base: Row[] = [
    {nim: "2208160001", nama: "Ahmad Fauzi", email: "ahmad.fauzi@student.ac.id"},
    {nim: "2208160014", nama: "Siti Rahmadani", email: "siti.rahma@student.ac.id"},
    {nim: "2308160027", nama: "Bima Prasetyo", email: "bima.p@student.ac.id"},
    {nim: "2408160005", nama: "Rizky Ananda", email: "rizky.a@student.ac.id"},
  ];
  const newRow: Row = {nim: "2408160042", nama: "Fadli Harahap", email: "fadli.h@student.ac.id"};
  const rows: (Row & {state?: string})[] = [...base, {...newRow, state: "new"}];
  const pop = spring({frame: local, fps, config: {damping: 14}});
  return (
    <Stage title="Empat operasi CRUD pada tabel mahasiswa">
      <div style={{position: "absolute", left: 48, top: 140, width: 470}}>
        <div style={{display: "flex", gap: 12, marginBottom: 24}}>
          {["C", "R", "U", "D"].map((k, i) => {
            const col = [C.g, C.pl, C.o, C.r][i];
            const on = i === ph;
            return <div key={k} style={{width: 74, height: 74, borderRadius: 20, background: on ? col : "#fff", border: `3px solid ${col}`, color: on ? "#fff" : col,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34, fontWeight: 800, scale: on ? String(0.85 + 0.15 * pop) : "1"}}>{k}</div>;
          })}
        </div>
        <div style={{fontSize: 44, fontWeight: 800, color: P.c, letterSpacing: -1}}>{P.n}</div>
        <div style={{marginTop: 16, background: "#272822", borderRadius: 16, padding: "18px 20px", fontFamily: MONO, fontSize: 19, color: "#f8f8f2", whiteSpace: "pre-wrap", minHeight: 120, lineHeight: 1.5}}>
          {type(P.sql, local, 4, 2.2)}
        </div>
        <div style={{marginTop: 14, fontFamily: MONO, fontSize: 18, color: P.c, fontWeight: 700, opacity: fade(local, 40, 55)}}>{P.fn}</div>
      </div>
      <div style={{position: "absolute", left: 570, top: 150, width: 660, background: "#fff", border: `2px solid ${C.line}`, borderRadius: 20, overflow: "hidden", boxShadow: "0 10px 30px rgba(79,91,147,.10)"}}>
        <div style={{display: "grid", gridTemplateColumns: "150px 170px 1fr", background: C.px, color: C.p, fontWeight: 800, fontSize: 17, padding: "12px 18px"}}>
          <div>nim</div><div>nama</div><div>email</div>
        </div>
        {rows.map((r, i) => {
          const isNew = r.state === "new";
          const isDel = i === 2;
          const isUpd = i === 1;
          let h = 52, op = 1, bg = i % 2 ? "#FAFAFD" : "#fff", tx = 0;
          if (isNew) {
            const t = ph === 0 ? interpolate(local, [30, 55], [0, 1], {...clamp, easing: ease}) : 1;
            h = 52 * t; op = t; tx = (1 - t) * 60;
            if (ph === 0 && local > 30) bg = C.gx;
          }
          if (ph === 1 && /a/i.test(r.nama) && local > 30) {
            const scan = Math.floor((local - 30) / 9);
            if (scan >= i) bg = C.px;
          }
          if (isUpd && ph === 2) bg = local > 35 ? C.ox : bg;
          if (isDel && ph >= 3) {
            const t = ph === 3 ? interpolate(local, [40, 70], [0, 1], {...clamp, easing: ease}) : 1;
            bg = C.rx; h = 52 * (1 - t); op = 1 - t;
          }
          const email = isUpd && (ph > 2 || (ph === 2 && local > 35)) ? "siti.rahmadani@student.ac.id" : r.email;
          return (
            <div key={r.nim} style={{display: "grid", gridTemplateColumns: "150px 170px 1fr", height: h, opacity: op, overflow: "hidden", alignItems: "center",
              padding: "0 18px", background: bg, fontFamily: MONO, fontSize: 16, borderTop: `1px solid ${C.line}`, translate: `${tx}px 0px`}}>
              <div>{r.nim}</div><div style={{fontFamily: FONT, fontWeight: 600}}>{r.nama}</div>
              <div style={{color: isUpd && ph === 2 && local > 35 ? C.o : C.ink, fontWeight: isUpd && ph === 2 && local > 35 ? 700 : 400}}>{email}</div>
            </div>
          );
        })}
      </div>
      <div style={{position: "absolute", left: 570, top: 520, width: 660, fontSize: 20, color: C.mut, fontWeight: 600, opacity: fade(local, 55, 70)}}>
        {["+1 baris baru tersimpan, id AUTO_INCREMENT diberikan", "baris yang namanya memuat huruf 'a' ikut terpilih", "1 baris berubah: kolom email diperbarui", "1 baris terhapus dari tabel"][ph]}
      </div>
    </Stage>
  );
};

// ------------------------------------------------------------- 3. SQL Injection
export const SqlInjection: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const input = "admin' -- ";
  const typed = type(input, f, 10, 0.4);
  const leftOn = fade(f, 60, 80);
  const rightOn = fade(f, 190, 210);
  const stampL = spring({frame: f - 150, fps, config: {damping: 11}});
  const stampR = spring({frame: f - 290, fps, config: {damping: 11}});
  return (
    <Stage title="Input yang sama, nasib yang berbeda">
      <div style={{position: "absolute", left: 48, top: 130, display: "flex", alignItems: "center", gap: 18}}>
        <div style={{fontSize: 22, fontWeight: 700, color: C.mut}}>Username yang diketik penyerang:</div>
        <div style={{minWidth: 300, background: "#fff", border: `3px solid ${C.o}`, borderRadius: 14, padding: "10px 18px", fontFamily: MONO, fontSize: 28, fontWeight: 700, color: C.r}}>
          {typed}<span style={{opacity: Math.floor(f / 15) % 2 ? 0 : 1, color: C.ink}}>|</span>
        </div>
      </div>
      {/* kiri: rentan */}
      <div style={{position: "absolute", left: 48, top: 215, width: 570, height: 400, background: C.rx, borderRadius: 24, padding: 26, opacity: leftOn, translate: `0px ${(1 - leftOn) * 30}px`}}>
        <div style={{fontSize: 24, fontWeight: 800, color: C.r}}>Rentan: input digabung ke string SQL</div>
        <div style={{marginTop: 18, background: "#272822", borderRadius: 14, padding: 18, fontFamily: MONO, fontSize: 18, color: "#f8f8f2", lineHeight: 1.6}}>
          <div>SELECT * FROM users</div>
          <div>WHERE username = '<span style={{color: "#fd971f", fontWeight: 700}}>{type("admin'", f, 85, 0.5)}</span>
            <span style={{color: "#f92672", fontWeight: 700}}>{f > 100 ? " -- " : ""}</span>'</div>
          <div style={{opacity: f > 115 ? 0.35 : 1, textDecoration: f > 115 ? "line-through" : "none"}}>AND password = '...'</div>
        </div>
        <div style={{marginTop: 16, fontSize: 19, fontWeight: 600, opacity: fade(f, 118, 130)}}>Tanda <b style={{fontFamily: MONO}}>--</b> menjadikan sisa query sebuah komentar, sehingga pemeriksaan password hilang.</div>
        <div style={{position: "absolute", right: 26, bottom: 24, rotate: "-8deg", scale: String(stampL), border: `5px solid ${C.r}`, color: C.r, borderRadius: 14, padding: "8px 18px", fontWeight: 800, fontSize: 26, background: "#fff"}}>LOGIN TEMBUS!</div>
      </div>
      {/* kanan: aman */}
      <div style={{position: "absolute", left: 662, top: 215, width: 570, height: 400, background: C.gx, borderRadius: 24, padding: 26, opacity: rightOn, translate: `0px ${(1 - rightOn) * 30}px`}}>
        <div style={{fontSize: 24, fontWeight: 800, color: C.g}}>Aman: prepared statement</div>
        <div style={{marginTop: 18, background: "#272822", borderRadius: 14, padding: 18, fontFamily: MONO, fontSize: 18, color: "#f8f8f2", lineHeight: 1.6}}>
          <div style={{color: "#75715e"}}>// 1. template dikirim dulu</div>
          <div>... WHERE username = <span style={{color: "#a6e22e", fontWeight: 700}}>?</span></div>
          <div style={{color: "#75715e", opacity: fade(f, 225, 240)}}>// 2. nilai dikirim terpisah</div>
          <div style={{opacity: fade(f, 230, 245)}}>? = <span style={{color: "#e6db74"}}>"admin' -- "</span></div>
        </div>
        <div style={{marginTop: 16, fontSize: 19, fontWeight: 600, opacity: fade(f, 255, 270)}}>Input diperlakukan sebagai <b>data</b>, bukan perintah. Database mencari user bernama persis <span style={{fontFamily: MONO}}>admin' --</span> yang tidak ada.</div>
        <div style={{position: "absolute", right: 26, bottom: 24, rotate: "-8deg", scale: String(stampR), border: `5px solid ${C.g}`, color: C.g, borderRadius: 14, padding: "8px 18px", fontWeight: 800, fontSize: 26, background: "#fff"}}>DITOLAK</div>
      </div>
    </Stage>
  );
};

// ------------------------------------------------------------- 4. Login + alur app
export const LoginFlow: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const user = type("admin", f, 10, 0.4);
  const pass = "•".repeat(Math.max(0, Math.min(8, Math.floor((f - 30) * 0.4))));
  const press = f > 58 && f < 66;
  const chips = [
    ["csrf_cek()", "token form valid", C.o, 70],
    ["SELECT ... WHERE username = ?", "prepared statement", C.pl, 95],
    ["password_verify()", "hash cocok ✓", C.p, 120],
    ["session_regenerate_id(true)", "cegah session fixation", C.g, 145],
    ["redirect('index.php')", "flash: Selamat datang!", C.g, 170],
  ] as const;
  const dash = fade(f, 200, 225);
  return (
    <Stage title="Alur login aman di PHP native">
      <div style={{position: "absolute", left: 60, top: 150, width: 380, background: "#fff", border: `2px solid ${C.line}`, borderRadius: 22, padding: 28, boxShadow: "0 10px 30px rgba(79,91,147,.12)",
        opacity: 1 - dash * 0.6}}>
        <div style={{fontSize: 28, fontWeight: 800, color: C.p, marginBottom: 18}}>Login</div>
        <div style={{fontSize: 16, fontWeight: 700, color: C.mut}}>Username</div>
        <div style={{border: `2px solid ${f < 30 ? C.pl : C.line}`, borderRadius: 12, padding: "10px 14px", fontSize: 22, margin: "6px 0 14px", height: 50, fontFamily: MONO}}>{user}</div>
        <div style={{fontSize: 16, fontWeight: 700, color: C.mut}}>Password</div>
        <div style={{border: `2px solid ${f >= 30 && f < 58 ? C.pl : C.line}`, borderRadius: 12, padding: "10px 14px", fontSize: 22, margin: "6px 0 18px", height: 50, letterSpacing: 4}}>{pass}</div>
        <div style={{background: C.p, color: "#fff", borderRadius: 12, padding: "12px", textAlign: "center", fontWeight: 800, fontSize: 20, scale: press ? "0.94" : "1"}}>Masuk</div>
      </div>
      <div style={{position: "absolute", left: 500, top: 150, width: 720}}>
        {chips.map(([fn, d, col, t], i) => {
          const s = spring({frame: f - t, fps, config: {damping: 16}});
          return (
            <div key={fn} style={{display: "flex", alignItems: "center", gap: 16, marginBottom: 16, opacity: s, translate: `${(1 - s) * 40}px 0px`}}>
              <div style={{width: 44, height: 44, borderRadius: 14, background: col, color: "#fff", fontWeight: 800, fontSize: 20, display: "flex", alignItems: "center", justifyContent: "center"}}>{i + 1}</div>
              <div style={{flex: 1, background: "#fff", border: `2px solid ${col}`, borderRadius: 14, padding: "10px 16px", display: "flex", justifyContent: "space-between", alignItems: "center"}}>
                <span style={{fontFamily: MONO, fontWeight: 700, fontSize: 19, color: col}}>{fn}</span>
                <span style={{fontSize: 16, color: C.mut, fontWeight: 600}}>{d}</span>
              </div>
            </div>
          );
        })}
      </div>
      <div style={{position: "absolute", left: 60, top: 548, width: 1160, opacity: dash, translate: `0px ${(1 - dash) * 30}px`, background: "#fff", border: `2px solid ${C.line}`, borderRadius: 18, padding: "16px 22px", display: "flex", gap: 22, alignItems: "center"}}>
        <div style={{background: C.gx, color: "#1f7a6f", borderRadius: 10, padding: "8px 16px", fontWeight: 700, fontSize: 19}}>Selamat datang, Administrator!</div>
        <div style={{fontSize: 19, fontWeight: 600, color: C.mut}}>$_SESSION['user_id'] tersimpan · halaman index.php kini dapat diakses</div>
      </div>
    </Stage>
  );
};
