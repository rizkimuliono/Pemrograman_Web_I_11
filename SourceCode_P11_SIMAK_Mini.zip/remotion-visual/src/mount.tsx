import React, {useEffect, useRef} from "react";
import {createRoot} from "react-dom/client";
import {Player, PlayerRef} from "@remotion/player";
import {RequestFlow, CrudOps, SqlInjection, LoginFlow} from "./comps";

const COMPS: Record<string, {c: React.FC; d: number}> = {
  request: {c: RequestFlow, d: 300},
  crud: {c: CrudOps, d: 360},
  sqli: {c: SqlInjection, d: 360},
  app: {c: LoginFlow, d: 270},
};

const Embed: React.FC<{name: string}> = ({name}) => {
  const ref = useRef<PlayerRef>(null);
  const wrap = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // putar otomatis saat terlihat di layar, jeda saat tidak terlihat
    const io = new IntersectionObserver(([e]) => {
      if (!ref.current) return;
      if (e.isIntersecting) ref.current.play(); else ref.current.pause();
    }, {threshold: 0.5});
    if (wrap.current) io.observe(wrap.current);
    return () => io.disconnect();
  }, []);
  const m = COMPS[name];
  return (
    <div ref={wrap}>
      <Player ref={ref} component={m.c} durationInFrames={m.d} compositionWidth={1280} compositionHeight={720} fps={30}
        controls loop clickToPlay acknowledgeRemotionLicense
        style={{width: "100%", aspectRatio: "16 / 9", borderRadius: 14, overflow: "hidden"}} />
    </div>
  );
};

(window as any).mountRemo = (el: HTMLElement, name: string) => {
  if (!COMPS[name]) return;
  createRoot(el).render(<Embed name={name} />);
};
