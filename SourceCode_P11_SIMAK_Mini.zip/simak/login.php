<?php
require_once 'config/koneksi.php';
require_once 'inc/fungsi.php';

if (!empty($_SESSION['user_id'])) redirect('index.php');   // sudah login

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // 1. Cari user berdasarkan username (prepared statement)
    $sql  = "SELECT id, password, nama_lengkap, role FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    // 2. Cocokkan password dengan hash yang tersimpan
    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);            // cegah session fixation
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama']    = $user['nama_lengkap'];
        $_SESSION['role']    = $user['role'];
        set_flash("Selamat datang, {$user['nama_lengkap']}!");
        redirect('index.php');
    }
    $error = "Username atau password salah.";   // pesan dibuat umum
}

$judul = "Login";
include 'inc/header.php';
?>
<?= get_flash() ?>
<?php if ($error): ?><div class="alert gagal"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="kartu login">
  <?= csrf_field() ?>
  <label>Username</label>
  <input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" required>
  <label>Password</label>
  <input type="password" name="password" required>
  <button type="submit" class="btn">Masuk</button>
</form>
<?php include 'inc/footer.php'; ?>
