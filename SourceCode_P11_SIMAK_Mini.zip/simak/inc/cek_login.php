<?php
require_once __DIR__ . '/fungsi.php';

// Penjaga halaman: hanya untuk pengguna yang sudah login
if (empty($_SESSION['user_id'])) {
    set_flash("Silakan login terlebih dahulu.", "gagal");
    redirect("login.php");
}
