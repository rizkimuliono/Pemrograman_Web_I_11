<?php foreach ($error as $err): ?>
  <div class="alert gagal"><?= e($err) ?></div>
<?php endforeach; ?>
<form method="post" class="kartu">
  <?= csrf_field() ?>
  <label>NIM</label>
  <input type="text" name="nim" value="<?= e($data['nim']) ?>" required>
  <label>Nama Lengkap</label>
  <input type="text" name="nama" value="<?= e($data['nama']) ?>" required>
  <label>Program Studi</label>
  <select name="prodi">
    <option value="">-- pilih --</option>
    <?php foreach (['Teknik Informatika', 'Sistem Informasi'] as $p): ?>
      <option <?= $data['prodi'] === $p ? 'selected' : '' ?>><?= $p ?></option>
    <?php endforeach; ?>
  </select>
  <label>Angkatan</label>
  <input type="number" name="angkatan" value="<?= e($data['angkatan']) ?>">
  <label>Email</label>
  <input type="email" name="email" value="<?= e($data['email']) ?>">
  <div class="aksi">
    <button type="submit" class="btn">Simpan</button>
    <a href="index.php" class="btn abu">Batal</a>
  </div>
</form>
