<?php
// Mulai session (dipakai untuk login, flash message, dan CSRF)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Escape output -> mencegah XSS
function e($teks) {
    return htmlspecialchars($teks ?? '', ENT_QUOTES, 'UTF-8');
}

// Pindah halaman lalu hentikan script
function redirect($url) {
    header("Location: $url");
    exit;
}

// Flash message: pesan yang tampil satu kali setelah redirect
function set_flash($pesan, $tipe = 'sukses') {
    $_SESSION['flash'] = ['pesan' => $pesan, 'tipe' => $tipe];
}
function get_flash() {
    if (empty($_SESSION['flash'])) return '';
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return "<div class='alert {$f['tipe']}'>" . e($f['pesan']) . "</div>";
}

// Token CSRF untuk setiap form POST
function csrf_field() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}
function csrf_cek() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(403);
        die("Permintaan tidak valid (token CSRF salah).");
    }
}

// Ambil input form mahasiswa dari $_POST
function ambil_input_mahasiswa() {
    return [
        'nim'      => trim($_POST['nim'] ?? ''),
        'nama'     => trim($_POST['nama'] ?? ''),
        'prodi'    => $_POST['prodi'] ?? '',
        'angkatan' => (int) ($_POST['angkatan'] ?? 0),
        'email'    => trim($_POST['email'] ?? ''),
    ];
}

// Validasi sisi server, mengembalikan daftar pesan error
function validasi_mahasiswa($d) {
    $error = [];
    if (!preg_match('/^[0-9]{8,12}$/', $d['nim']))
        $error[] = "NIM harus 8-12 digit angka.";
    if (mb_strlen($d['nama']) < 3)
        $error[] = "Nama minimal 3 karakter.";
    if (!in_array($d['prodi'], ['Teknik Informatika', 'Sistem Informasi']))
        $error[] = "Program studi wajib dipilih.";
    if ($d['angkatan'] < 2015 || $d['angkatan'] > (int) date('Y'))
        $error[] = "Tahun angkatan tidak valid.";
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL))
        $error[] = "Format email tidak valid.";
    return $error;
}
