<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($judul ?? 'SIMAK Mini') ?> | SIMAK Mini</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<nav>
  <b>SIMAK<span>Mini</span></b>
  <?php if (!empty($_SESSION['user_id'])): ?>
    <span class="user"><?= e($_SESSION['nama']) ?> (<?= e($_SESSION['role']) ?>)
      &middot; <a href="logout.php">Logout</a></span>
  <?php endif; ?>
</nav>
<main>
  <h1><?= e($judul ?? '') ?></h1>
