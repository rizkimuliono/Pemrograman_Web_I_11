<?php
require_once 'config/koneksi.php';
require_once 'inc/cek_login.php';

$data  = ['nim' => '', 'nama' => '', 'prodi' => '', 'angkatan' => date('Y'), 'email' => ''];
$error = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $data  = ambil_input_mahasiswa();     // 1. ambil input
    $error = validasi_mahasiswa($data);   // 2. validasi

    if (!$error) {                        // 3. simpan jika valid
        $sql  = "INSERT INTO mahasiswa (nim, nama, prodi, angkatan, email)
                 VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssis", $data['nim'], $data['nama'],
                               $data['prodi'], $data['angkatan'], $data['email']);
        try {
            mysqli_stmt_execute($stmt);
            set_flash("Data {$data['nama']} berhasil ditambahkan.");
            redirect('index.php');
        } catch (mysqli_sql_exception $e) {
            // 1062 = Duplicate entry (NIM sudah ada)
            $error[] = $e->getCode() == 1062
                     ? "NIM sudah terdaftar." : "Gagal menyimpan data.";
        }
    }
}

$judul = "Tambah Mahasiswa";
include 'inc/header.php';
include 'inc/form_mahasiswa.php';   // form dipakai bersama oleh tambah & edit
include 'inc/footer.php';
