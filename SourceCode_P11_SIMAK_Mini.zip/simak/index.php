<?php
require_once 'config/koneksi.php';
require_once 'inc/cek_login.php';

// READ: tampilkan semua data, atau hasil pencarian
$cari = trim($_GET['cari'] ?? '');

if ($cari !== '') {
    $sql  = "SELECT * FROM mahasiswa WHERE nim LIKE ? OR nama LIKE ? ORDER BY nim";
    $stmt = mysqli_prepare($conn, $sql);
    $kata = "%$cari%";
    mysqli_stmt_bind_param($stmt, "ss", $kata, $kata);
    mysqli_stmt_execute($stmt);
    $hasil = mysqli_stmt_get_result($stmt);
} else {
    $hasil = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY nim");
}
$jumlah = mysqli_num_rows($hasil);

$judul = "Data Mahasiswa";
include 'inc/header.php';
?>
<?= get_flash() ?>
<form method="get" class="cari">
  <input type="text" name="cari" value="<?= e($cari) ?>" placeholder="Cari NIM / nama">
  <button class="btn abu">Cari</button>
  <a href="tambah.php" class="btn">+ Tambah Data</a>
</form>
<p class="info">Menampilkan <b><?= $jumlah ?></b> data mahasiswa.</p>
<table>
  <tr><th>No</th><th>NIM</th><th>Nama</th><th>Prodi</th>
      <th>Angkatan</th><th>Email</th><th>Aksi</th></tr>
  <?php $no = 1; while ($row = mysqli_fetch_assoc($hasil)): ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= e($row['nim']) ?></td>
    <td><?= e($row['nama']) ?></td>
    <td><?= e($row['prodi']) ?></td>
    <td><?= e($row['angkatan']) ?></td>
    <td><?= e($row['email']) ?></td>
    <td class="aksi">
      <a href="edit.php?id=<?= $row['id'] ?>" class="btn kecil">Edit</a>
      <form method="post" action="hapus.php" onsubmit="return confirm('Hapus data ini?')">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <button class="btn kecil merah">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endwhile; ?>
</table>
<?php include 'inc/footer.php'; ?>
