-- =============================================
-- Database : db_kampus  (Pertemuan 11 - PHP CRUD)
-- =============================================
CREATE DATABASE IF NOT EXISTS db_kampus
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_kampus;

-- Tabel pengguna aplikasi (untuk login)
CREATE TABLE users (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  username     VARCHAR(50)  NOT NULL UNIQUE,
  password     VARCHAR(255) NOT NULL,      -- hasil password_hash()
  nama_lengkap VARCHAR(100) NOT NULL,
  role         ENUM('admin','operator') NOT NULL DEFAULT 'operator',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel data utama yang di-CRUD
CREATE TABLE mahasiswa (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nim        VARCHAR(12)  NOT NULL UNIQUE,
  nama       VARCHAR(100) NOT NULL,
  prodi      VARCHAR(50)  NOT NULL,
  angkatan   YEAR         NOT NULL,
  email      VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
             ON UPDATE CURRENT_TIMESTAMP
);

-- Akun awal  ->  admin / admin123   dan   operator / operator123
INSERT INTO users (username, password, nama_lengkap, role) VALUES
('admin',    '$2y$10$.cknSs3ShVs6f6qaSBQJn.hffTym6NuO3UHqJn1UAvyYgoI5Vbj7G', 'Administrator',  'admin'),
('operator', '$2y$10$7Ke9TO8gTFK/1VC3Ub2LyOhsxsg7eiVs5ILr7dIBc1QuazHAul3l6', 'Operator Prodi', 'operator');

INSERT INTO mahasiswa (nim, nama, prodi, angkatan, email) VALUES
('2208160001', 'Ahmad Fauzi',      'Teknik Informatika', 2022, 'ahmad.fauzi@student.ac.id'),
('2208160014', 'Siti Rahmadani',   'Teknik Informatika', 2022, 'siti.rahma@student.ac.id'),
('2308160027', 'Bima Prasetyo',    'Sistem Informasi',   2023, 'bima.p@student.ac.id'),
('2308160031', 'Nurul Hidayah',    'Teknik Informatika', 2023, 'nurul.h@student.ac.id'),
('2408160005', 'Rizky Ananda',     'Sistem Informasi',   2024, 'rizky.a@student.ac.id'),
('2408160019', 'Putri Wulandari',  'Teknik Informatika', 2024, 'putri.w@student.ac.id');
