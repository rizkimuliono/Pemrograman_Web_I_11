<?php
// ===== Konfigurasi database (sesuaikan dengan XAMPP) =====
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "db_kampus";

// Mode exception: setiap error query dilempar sebagai exception
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    mysqli_set_charset($conn, "utf8mb4");
} catch (mysqli_sql_exception $e) {
    error_log($e->getMessage());   // detail error dicatat di log server
    die("Koneksi database gagal. Silakan hubungi administrator.");
}
