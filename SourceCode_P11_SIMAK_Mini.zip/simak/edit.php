<?php
require_once 'config/koneksi.php';
require_once 'inc/cek_login.php';

$id = (int) ($_GET['id'] ?? 0);

// 1. Ambil data lama berdasarkan id
$stmt = mysqli_prepare($conn, "SELECT * FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$data) {
    set_flash("Data tidak ditemukan.", "gagal");
    redirect('index.php');
}

$error = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $data  = ambil_input_mahasiswa();     // 2. ambil input baru
    $error = validasi_mahasiswa($data);

    if (!$error) {                        // 3. simpan perubahan
        $sql  = "UPDATE mahasiswa SET nim = ?, nama = ?, prodi = ?, angkatan = ?, email = ?
                 WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssisi", $data['nim'], $data['nama'],
                               $data['prodi'], $data['angkatan'], $data['email'], $id);
        try {
            mysqli_stmt_execute($stmt);
            set_flash("Data {$data['nama']} berhasil diperbarui.");
            redirect('index.php');
        } catch (mysqli_sql_exception $e) {
            $error[] = $e->getCode() == 1062
                     ? "NIM sudah dipakai mahasiswa lain." : "Gagal memperbarui data.";
        }
    }
}

$judul = "Edit Mahasiswa";
include 'inc/header.php';
include 'inc/form_mahasiswa.php';
include 'inc/footer.php';
