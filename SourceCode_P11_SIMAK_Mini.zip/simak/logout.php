<?php
require_once 'inc/fungsi.php';

$_SESSION = [];          // kosongkan semua data session
session_destroy();       // hapus session di server
redirect('login.php');
