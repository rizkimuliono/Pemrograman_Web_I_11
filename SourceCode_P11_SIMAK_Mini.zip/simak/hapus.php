<?php
require_once 'config/koneksi.php';
require_once 'inc/cek_login.php';

// Hapus hanya lewat POST + token CSRF (bukan link GET)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php');
csrf_cek();

// Access control: hanya admin yang boleh menghapus
if ($_SESSION['role'] !== 'admin') {
    set_flash("Akses ditolak: hanya admin yang dapat menghapus data.", "gagal");
    redirect('index.php');
}

$id   = (int) ($_POST['id'] ?? 0);
$stmt = mysqli_prepare($conn, "DELETE FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

if (mysqli_stmt_affected_rows($stmt) > 0) {
    set_flash("Data berhasil dihapus.");
} else {
    set_flash("Data tidak ditemukan.", "gagal");
}
redirect('index.php');
