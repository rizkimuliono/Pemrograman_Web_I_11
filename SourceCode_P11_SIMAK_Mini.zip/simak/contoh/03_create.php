<?php
// Contoh 3 : CREATE - menambah data dengan INSERT + prepared statement
require '../config/koneksi.php';

$nim   = "2408160099";
$nama  = "Dewi Lestari";
$prodi = "Sistem Informasi";
$tahun = 2024;
$email = "dewi.l@student.ac.id";

// 1. Siapkan query dengan placeholder (?)
$stmt = mysqli_prepare($conn,
    "INSERT INTO mahasiswa (nim, nama, prodi, angkatan, email) VALUES (?, ?, ?, ?, ?)");

// 2. Ikat nilai ke placeholder: s = string, i = integer
mysqli_stmt_bind_param($stmt, "sssis", $nim, $nama, $prodi, $tahun, $email);

// 3. Jalankan
mysqli_stmt_execute($stmt);

echo "Baris ditambahkan : " . mysqli_stmt_affected_rows($stmt) . "<br>";
echo "ID baru (AUTO_INCREMENT) : " . mysqli_insert_id($conn);
