<?php
// Contoh 5 : DELETE - menghapus data berdasarkan NIM
require '../config/koneksi.php';

$nim  = "2408160099";
$stmt = mysqli_prepare($conn, "DELETE FROM mahasiswa WHERE nim = ?");
mysqli_stmt_bind_param($stmt, "s", $nim);
mysqli_stmt_execute($stmt);

if (mysqli_stmt_affected_rows($stmt) > 0) {
    echo "&#9989; Data NIM $nim berhasil dihapus.";
} else {
    echo "&#9888; Data NIM $nim tidak ditemukan.";
}
