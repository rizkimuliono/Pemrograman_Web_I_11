<?php
// Contoh 1 : Membuka koneksi ke MySQL/MariaDB dengan MySQLi
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = mysqli_connect("localhost", "root", "", "db_kampus");
    mysqli_set_charset($conn, "utf8mb4");

    echo "<h3>&#9989; Koneksi berhasil</h3>";
    echo "Server  : " . mysqli_get_server_info($conn) . "<br>";
    echo "Host    : " . mysqli_get_host_info($conn) . "<br>";
    echo "Charset : " . mysqli_character_set_name($conn);
} catch (mysqli_sql_exception $e) {
    echo "<h3>&#10060; Koneksi gagal</h3>";
    echo "Pesan : " . $e->getMessage();
}
