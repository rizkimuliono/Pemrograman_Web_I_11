<?php
// Contoh 4 : UPDATE - mengubah data berdasarkan NIM
require '../config/koneksi.php';

$email_baru = "dewi.lestari@student.ac.id";
$nim        = "2408160099";

$stmt = mysqli_prepare($conn, "UPDATE mahasiswa SET email = ? WHERE nim = ?");
mysqli_stmt_bind_param($stmt, "ss", $email_baru, $nim);
mysqli_stmt_execute($stmt);

echo "Baris berubah : " . mysqli_stmt_affected_rows($stmt) . "<br>";

// Cek hasilnya
$stmt = mysqli_prepare($conn, "SELECT nama, email FROM mahasiswa WHERE nim = ?");
mysqli_stmt_bind_param($stmt, "s", $nim);
mysqli_stmt_execute($stmt);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
echo "Data sekarang : {$row['nama']} &lt;{$row['email']}&gt;";
