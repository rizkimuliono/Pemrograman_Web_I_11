<?php
// Contoh 8 : Login aman - prepared statement + password_verify()
require '../config/koneksi.php';

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$stmt = mysqli_prepare($conn, "SELECT username, password FROM users WHERE username = ?");
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$u = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

echo "Input username : <code>" . htmlspecialchars($username) . "</code><br><br>";
if ($u && password_verify($password, $u['password'])) {
    echo "&#9989; Login berhasil sebagai <b>" . htmlspecialchars($u['username']) . "</b>";
} else {
    echo "&#128274; Login ditolak. Input dianggap data biasa, bukan perintah SQL.";
}
