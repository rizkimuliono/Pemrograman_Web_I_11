<?php
// Contoh 7 : JANGAN DITIRU! Login rentan SQL Injection (hanya untuk demo lokal)
require '../config/koneksi.php';

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Input digabung langsung ke dalam string SQL
$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
echo "<code>" . htmlspecialchars($sql) . "</code><br><br>";

$hasil = mysqli_query($conn, $sql);
if (mysqli_num_rows($hasil) > 0) {
    $u = mysqli_fetch_assoc($hasil);
    echo "&#128275; LOGIN BERHASIL sebagai <b>{$u['username']}</b> (tanpa tahu password!)";
} else {
    echo "Login gagal.";
}
