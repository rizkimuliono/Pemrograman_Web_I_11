<?php
// Contoh 9 : Mencegah XSS dengan htmlspecialchars()
$komentar = '<script>alert("Akun Anda diretas!")</script><b>Halo</b>';

echo "<b>Tanpa escape</b> (browser menjalankan script):<br>";
echo "<div style='border:1px dashed red;padding:6px'>[dinonaktifkan untuk demo]</div><br>";

echo "<b>Dengan htmlspecialchars()</b> (tampil sebagai teks biasa):<br>";
echo "<div style='border:1px dashed green;padding:6px'>"
   . htmlspecialchars($komentar, ENT_QUOTES, 'UTF-8') . "</div>";
