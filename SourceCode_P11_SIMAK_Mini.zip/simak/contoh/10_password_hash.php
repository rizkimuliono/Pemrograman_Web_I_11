<?php
// Contoh 10 : Menyimpan password dengan aman
$password = "admin123";

$hash1 = password_hash($password, PASSWORD_DEFAULT);   // bcrypt (default)
$hash2 = password_hash($password, PASSWORD_DEFAULT);   // salt berbeda tiap kali

echo "Password asli : $password<br>";
echo "Hash 1 : $hash1<br>";
echo "Hash 2 : $hash2<br><br>";

var_dump(password_verify("admin123", $hash1));   // true
echo "<br>";
var_dump(password_verify("admin321", $hash1));   // false
echo "<br><br>MD5 (JANGAN dipakai) : " . md5($password);
