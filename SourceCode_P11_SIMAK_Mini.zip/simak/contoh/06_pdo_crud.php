<?php
// Contoh 6 : CRUD lengkap dengan PDO
$dsn = "mysql:host=localhost;dbname=db_kampus;charset=utf8mb4";
$pdo = new PDO($dsn, "root", "", [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // error = exception
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // hasil = array asosiatif
]);

// CREATE - named placeholder (:nama)
$stmt = $pdo->prepare("INSERT INTO mahasiswa (nim, nama, prodi, angkatan, email)
                       VALUES (:nim, :nama, :prodi, :angkatan, :email)");
$stmt->execute([':nim' => '2408160100', ':nama' => 'Andi Saputra',
                ':prodi' => 'Teknik Informatika', ':angkatan' => 2024,
                ':email' => 'andi.s@student.ac.id']);
$id = $pdo->lastInsertId();
echo "CREATE : id baru = $id<br>";

// READ - satu baris
$stmt = $pdo->prepare("SELECT nim, nama FROM mahasiswa WHERE id = ?");
$stmt->execute([$id]);
$mhs = $stmt->fetch();
echo "READ   : {$mhs['nim']} - {$mhs['nama']}<br>";

// UPDATE
$stmt = $pdo->prepare("UPDATE mahasiswa SET nama = ? WHERE id = ?");
$stmt->execute(['Andi Saputra Nasution', $id]);
echo "UPDATE : " . $stmt->rowCount() . " baris diubah<br>";

// DELETE
$stmt = $pdo->prepare("DELETE FROM mahasiswa WHERE id = ?");
$stmt->execute([$id]);
echo "DELETE : " . $stmt->rowCount() . " baris dihapus<br>";

// READ - banyak baris
$total = $pdo->query("SELECT COUNT(*) FROM mahasiswa")->fetchColumn();
echo "Total mahasiswa sekarang : $total";
