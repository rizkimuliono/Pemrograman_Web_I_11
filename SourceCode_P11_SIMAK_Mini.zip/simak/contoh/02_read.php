<?php
// Contoh 2 : READ - menampilkan data dengan SELECT
require '../config/koneksi.php';

$hasil = mysqli_query($conn, "SELECT nim, nama, prodi FROM mahasiswa ORDER BY nim LIMIT 4");

echo "Jumlah baris: " . mysqli_num_rows($hasil) . "<br><br>";

// Ambil baris satu per satu sebagai array asosiatif
while ($row = mysqli_fetch_assoc($hasil)) {
    echo $row['nim'] . " - " . htmlspecialchars($row['nama'])
       . " (" . $row['prodi'] . ")<br>";
}

// Alternatif: ambil semua baris sekaligus
$semua = mysqli_fetch_all(mysqli_query($conn, "SELECT nama FROM mahasiswa"), MYSQLI_ASSOC);
echo "<br>Total dengan fetch_all(): " . count($semua) . " mahasiswa";
